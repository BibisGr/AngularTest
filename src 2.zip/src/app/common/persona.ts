export interface Persona {
    nombre: string;
    edad: number;
    mayor: boolean;
}
